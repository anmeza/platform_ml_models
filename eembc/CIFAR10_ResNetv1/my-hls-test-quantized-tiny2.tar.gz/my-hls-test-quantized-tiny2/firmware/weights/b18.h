//Numpy array shape [10]
//Min -0.468750000000
//Max 0.593750000000
//Number of zeros 0

#ifndef B18_H_
#define B18_H_

#ifndef __SYNTHESIS__
bias18_t b18[10];
#else
bias18_t b18[10] = {0.21875, -0.46875, -0.31250, 0.12500, 0.34375, -0.15625, 0.59375, -0.31250, 0.09375, -0.15625};
#endif

#endif
