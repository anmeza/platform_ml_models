//Numpy array shape [4]
//Min -0.156250000000
//Max 0.031250000000
//Number of zeros 1

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
bias5_t b5[4];
#else
bias5_t b5[4] = {2.12500, 3.96875, -2.56250, 2.31250};
#endif

#endif
